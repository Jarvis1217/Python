from django.apps import AppConfig


class MscDownloadConfig(AppConfig):
    name = 'msc_download'
